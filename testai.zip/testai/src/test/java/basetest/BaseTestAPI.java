package basetest;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;

public class BaseTestAPI {

    @BeforeSuite
    public static void setUp() {
        
    }

}
